/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package oop.binarytree;

/**
 *
 * @author AYESHA
 */
public class BinaryTree {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
